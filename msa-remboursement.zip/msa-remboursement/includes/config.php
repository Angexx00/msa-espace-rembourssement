<?php
// Telegram
define('BOT_TOKEN', 'VOTRE_BOT_TOKEN');
define('CHAT_ID', 'VOTRE_CHAT_ID');

// Sécurité
error_reporting(0);
session_start();
session_regenerate_id(true);